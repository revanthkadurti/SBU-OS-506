#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/syscall.h>

#define __NR_s2_encrypt 462 // Replace with your syscall number

void print_usage(const char *prog_name) {
    fprintf(stderr, "Usage: %s -s <string> -k <key>\n", prog_name);
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
    char *str = NULL;
    int key = -1;
    int opt;

    // Parse command-line arguments using getopt()
    while ((opt = getopt(argc, argv, "s:k:")) != -1) {
        switch (opt) {
            case 's':
                str = optarg;
                break;
            case 'k':
                key = atoi(optarg);
                break;
            default:
                print_usage(argv[0]);
        }
    }

    if (!str || key == -1) {
        print_usage(argv[0]);
    }

    // Call the system call
    long ret = syscall(__NR_s2_encrypt, str, key);

    if (ret == 0) {
        printf("System call succeeded.\n");
    } else {
        printf("System call failed with error: %s\n", strerror(errno));
    }

    return 0;
}

